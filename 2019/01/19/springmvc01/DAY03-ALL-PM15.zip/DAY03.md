### 1. 使用Session

通常，会在Session中存放：

1. 客户端（用户）的身份标识，通常是用户的id；
2. 使用频率非常高的数据，例如显示在页面中的用户名、头像等；
3. 其它的不便于使用其它存储方案来存取或传递的数据。

关于Session的使用，和`ModelMap`几乎一样，即在处理请求的方法中添加`HttpSession`参数，并在方法体中操作该参数对象即可。

### 2. 拦截器：Interceptor

Spring MVC中的拦截器(Interceptor)与Java EE中的过滤器(Filter)比较相似，可以对某些请求尝试拦截，由开发者自行编写拦截的逻辑，使得某些请求可以执行，而某些请求将不允许执行，实现统一管理的效果。

在使用时，必须先自定义拦截器类，实现`HandlerInterceptor`接口，然后在Spring的配置文件中进行配置。

当实现`HandlerInterceptor`接口后，需要重写3个未实现的方法，其中，`public boolean preHandle()`方法是起到拦截作用的，在运行在控制器之前的，该方法的返回值是boolean类型的，表示是否放行，即返回true则放行，返回false则拦截！一旦拦截，控制器方法将不会被执行，并且拦截器中剩下的2个方法也不会被执行，如果通过浏览器进行访问，界面将显示一片空白！

注意：即使执行重定向语法，如果拦截器`return true;`，依然会执行控制器中的方法和拦截器中另2个方法，则没有拦截效果，所以，当符合拦截条件时，应该`return false;`。

关于拦截器的配置大致如下：

	<!-- 拦截器链 -->
	<mvc:interceptors>
		<!-- 第1个拦截器 -->
		<mvc:interceptor>
			<!-- 拦截路径 -->
			<mvc:mapping path="/user/index.do"/>
			<!-- 拦截器类 -->
			<bean class="cn.tedu.spring.interceptor.LoginInterceptor"></bean>
		</mvc:interceptor>
		<!-- 第2个拦截器 -->
		<!-- 第3个拦截器 -->
		<!-- 第N个拦截器 -->
	</mvc:interceptors>

即：SpringMVC是支持**拦截器链**的，在同一个项目中，允许存在多个拦截器，形成拦截器链，多个拦截器的执行先后顺序取决于配置的先后顺序。

在配置每一个拦截器的`<mvc:interceptor>`节点中，`<mvc:mapping>`节点用于配置需要拦截的路径，该节点可以存在若干个，例如：

	<mvc:interceptor>
		<!-- 拦截路径 -->
		<mvc:mapping path="/user/index.do"/>
		<mvc:mapping path="/user/logout.do"/>
		<!-- 拦截器类 -->
		<bean class="cn.tedu.spring.interceptor.LoginInterceptor"></bean>
	</mvc:interceptor>

并且，在配置路径时，是支持通配符的，例如：

	<mvc:mapping path="/user/*"/>

即：例如`/user/reg.do`、`/user/login.do`、`/user/handle_reg.do`等这些路径都在拦截范围之内！

但是，需要注意的是：1个星号表示的通配符只能匹配1层路径，例如`/user/*`不可以匹配到`/user/news/list.do`这样的路径！如果要匹配若干层路径，可以使用2个星号，例如配置为`/user/**`。

除此以外，在配置时，还可以添加`<mvc:exclude-mapping>`节点，以配置例外，例如：

	<!-- 拦截路径 -->
	<mvc:mapping path="/user/*"/>
	<!-- 添加例外 -->
	<mvc:exclude-mapping path="/user/reg.do"/>
	<mvc:exclude-mapping path="/user/login.do"/>
	<mvc:exclude-mapping path="/user/handle_reg.do"/>
	<mvc:exclude-mapping path="/user/handle_login.do"/>

关于`<mvc:exclude-mapping>`的配置方式，与`<mvc:mapping>`相同，也可以使用通配符。

以上`<mvc:mapping>`也可以理解为**拦截名单**，而`<mvc:exclude-mapping>`就是**白名单**。

以上配置是必须有先后顺序的，`<mvc:mapping>`必须在最前，其次是`<mvc:exclude-mapping>`，最后是拦截器`<bean>`。

仅在拦截范围之内的，才会触发拦截器执行（无论最终是拦截还是放行），如果某路径不在拦截范围之内（包含被添加到例外的），将根本就不触发拦截器的执行。

### 3. SpringMVC项目的乱码解决方案

整个SpringMVC框架默认使用的编码都是ISO-8859-1，是不支持中文的，所以，在`DispatcherServlet`接收到请求的那一刻起，数据的编码就已经是ISO-8859-1，为了修改编码，只能通过过滤器(Filter)来设置，在SpringMVC中也定义好了`CharacterEncodingFilter`，用于设置字符编码，所以，当使用SpringMVC时，应该在`web.xml`中配置该过滤器，并为这个过滤器类的`encoding`属性设置编码值：

	<filter>
		<filter-name>CharacterEncodingFilter</filter-name>
		<filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
		<init-param>
			<param-name>encoding</param-name>
			<param-value>utf-8</param-value>
		</init-param>
	</filter>

	<filter-mapping>
		<filter-name>CharacterEncodingFilter</filter-name>
		<url-pattern>/*</url-pattern>
	</filter-mapping>

### 4. SpringMVC处理异常

















### 【附】 拦截器和过滤器的区别

过滤器(Filter)是Java EE体系中的，而拦截器(Interceptor)是SpringMVC中的；

过滤器是在所有的Servlet之前执行的，而拦截器的初次执行是在DispatcherServlet之后、在Controller之前执行的；

过滤器的过滤范围只能在web.xml中通过<url-pattern>这1个节点来配置，而拦截器可以配置多个拦截路径，且可以添加例外，配置更加灵活；

所有的请求都可以被过滤器进行处理，却只有交由DispatcherServlet分发的请求才可能被拦截器处理！

### 【附】 字符编码问题 / 出错时的乱码问题

在不考虑某些编码不支持中文的情况下，使用了支持中文的编码，仍会出现乱码的原因只有1个：存和取的时候使用了不同的编码。

所以，解决方案就是：整个项目涉及的所有位置全部使用相同的编码！

通常，需要指定编码的位置有：
1. 项目的源代码，例如某个String类型数据的值；
2. 显示界面的组件所使用的编码，例如HTML/JSP使用的编码；
3. 数据存储位置使用的编码，例如数据库中的编码；
4. 数据传输过程中使用的编码，例如请求、响应，或数据库连接的URL。














	0, 1

	位：bit，二进制位，任何1个0或1所占用的空间就是1个二进制位，是计算机中最小的存储单位

	字节：byte，1个字节为8个二进制位，例如 0000 1100，字节是计算机存储数据的基本单位

	0000 0000
	0000 0001
	1111 1111

	ASCII编码

	a		0110 0001

	中文编码：GBK, GB2312, UTF-8

	中	0000 0000 0000 0000
	中	0000 0100 0000 0000

	


















	<filter>
		<filter-name></filter-name>
		<filter-class></filter-class>
	</filter>

	<filter-mapping>
		<filter-name></filter-name>
		<url-pattern>*.do</url-pattern>
	</filter-mapping>

	登录过滤器
		判断请求路径是否必须登录
		是：判断是否已登录
			是：放行
			否：重定向
		否：直接放行