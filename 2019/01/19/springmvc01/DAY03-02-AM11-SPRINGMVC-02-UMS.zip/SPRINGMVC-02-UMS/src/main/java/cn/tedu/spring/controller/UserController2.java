package cn.tedu.spring.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.tedu.spring.entity.User;

// ���ݴ���
@RequestMapping("user")
public class UserController2 {
	
	// http://localhost:8080/PROJECT/reg.do
	@RequestMapping("reg.do")
	public String showReg() {
		return "reg";
	}

	// http://localhost:8080/PROJECT/login.do
	@RequestMapping("login.do")
	public String showLogin() {
		return "login";
	}
	
	// http://localhost:8080/PROJECT/index.do
	@RequestMapping("index.do")
	public String showIndex() {
		return "index";
	}
	
	@PostMapping("handle_login.do")
	public String handleLogin(
			@RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println("username=" + username);
		System.out.println("password=" + password);
		return null;
	}
	
//	@RequestMapping(name="���ȡ��", 
//			path="handle_login.do",
//			method=RequestMethod.POST)
//	public String handleLogin(
//			String username, String password,
//			ModelMap modelMap) {
//		String message = null;
//		if ("root".equals(username)) {
//			if ("1234".equals(password)) {
//				return "redirect:index.do";
//			} else {
//				message = "[3] �������";
//				modelMap.addAttribute("msg", message);
//				return "error";
//			}
//		} else {
//			message = "[3] �û��������ڣ�";
//			modelMap.addAttribute("msg", message);
//			return "error";
//		}
//	}
	
//	@RequestMapping("handle_login.do")
//	public ModelAndView handleLogin(
//			String username, String password) {
//		String viewName = null;
//		String message = null;
//		Map<String, Object> model
//			= new HashMap<String, Object>();
//		if ("root".equals(username)) {
//			if ("1234".equals(password)) {
//				// ...
//			} else {
//				viewName = "error";
//				message = "[2] �������";
//				model.put("msg", message);
//			}
//		} else {
//			viewName = "error";
//			message = "[2] �û��������ڣ�";
//			model.put("msg", message);
//		}
//		
//		ModelAndView mav 
//			= new ModelAndView(viewName, model);
//		
//		return mav;
//	}
	
//	@RequestMapping("handle_login.do")
//	public String handleLogin(
//			HttpServletRequest request) {
//		String username = request.getParameter("username");
//		String password = request.getParameter("password");
//		
//		System.out.println("username=" + username);
//		System.out.println("password=" + password);
//		
//		// �ж��û���������
//		String message = null;
//		if ("root".equals(username)) {
//			if ("1234".equals(password)) {
//				// �û��������붼����ȷ��
//			} else {
//				message = "��������������";
//				request.setAttribute("msg", message);
//				return "error";
//			}
//		} else {
//			message = "�����Ե�¼���û���(" + username + ")�����ڣ�";
//			request.setAttribute("msg", message);
//			return "error";
//		}
//		System.out.println(message);
//		
//		// �ݲ����ĺ�����ҳ��
//		return null;
//	}
	
//	@RequestMapping("handle_reg.do")
//	public String handleReg(
//			String username, String password,
//			Integer age, String phone,
//			String email) {
//		System.out.println("username=" + username);
//		System.out.println("password=" + password);
//		System.out.println("age=" + age);
//		System.out.println("phone=" + phone);
//		System.out.println("email=" + email);
//		
//		// �ݲ����ĺ�����ҳ��
//		return null;
//	}
	
	@RequestMapping("handle_reg.do")
	public String handleReg(User user) {
		System.out.println(user);
		
		// �ݲ����ĺ�����ҳ��
		return null;
	}
	
}






