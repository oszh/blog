package cn.tedu.spring.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.tedu.spring.entity.User;

@Controller
@RequestMapping("user")
public class UserController {
	
	@GetMapping("reg.do")
	public String showReg() {
		return "reg";
	}
	
	@GetMapping("login.do")
	public String showLogin() {
		return "login";
	}
	
	@GetMapping("index.do")
	public String showIndex(HttpSession session) {
		System.out.println("showIndex() > " + session.getAttribute("username"));
		
		return "index";
	}
	
	@PostMapping("handle_reg.do")
	public String handleReg(User user, ModelMap modelMap) {
		if ("admin".equals(user.getUsername())) {
			String message
				= "������ע����û���(" + user.getUsername() + ")�Ѿ���ռ�ã�";
			modelMap.addAttribute("msg", message);
			return "error";
		}
		
		return "redirect:login.do";
	}
	
	@PostMapping("handle_login.do")
	public String handleLogin(
		@RequestParam("username") String username, 
		@RequestParam("password") String password,
		ModelMap modelMap,
		HttpSession session) {
		String message = null;
		if ("root".equals(username)) {
			if ("1234".equals(password)) {
				// ��¼�ɹ������û�������session
				session.setAttribute("username", username);
				System.out.println("handleLogin() > " + session.getAttribute("username"));
				return "redirect:index.do";
			} else {
				message = "�������";
			}
		} else {
			message = "�û�������";
		}
		modelMap.addAttribute("msg", message);
		return "error";
	}
	
	@GetMapping("logout.do")
	public String handleLogout(HttpSession session) {
		session.invalidate();
		return "redirect:login.do";
	}
	
}






